Lemon Tracking 0.1.0 — macOS / Linux local agent

This package is a background collector with a terminal control loop. It stores
the same local JSON record model as the Windows collector and asks for consent
before collection.

The release archives are framework-dependent and require the .NET 10 runtime
for the target platform.

Run:
  ./LemonTracking.Agent

First run:
  Type yes at the consent prompt, or use --accept when starting it from a
  controlled launcher.

Commands while it runs:
  pause
  resume
  stop
  Ctrl+C

Data is stored in the current user's local application-data directory under
LemonTracking. The agent records process/application identity, local timestamps,
duration, idle state, category, device and source. It does not store window
titles by default and does not collect keyboard, clipboard, screen, camera,
microphone or document contents.

Platform notes:
  macOS Apple Silicon: foreground application lookup uses System Events through
  osascript and may require Accessibility permission in System Settings. Idle
  time uses IOHIDSystem.
  Linux x86_64: X11 foreground lookup uses xprop. Idle time uses xprintidle
  when that utility is installed. Wayland sessions are identified separately;
  a compositor-specific foreground integration is outside this package.

This release is unsigned. Review the source and launch it from a terminal.
