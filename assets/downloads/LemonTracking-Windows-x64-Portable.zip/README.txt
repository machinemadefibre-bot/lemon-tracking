Lemon Tracking 0.1.0 — Windows x64

Run LemonTracking.Desktop.exe. On first run the application asks for consent before collection begins.

The collector stores local records under:
%LOCALAPPDATA%\LemonTracking

It records foreground process identity, timing, idle state, category, device and provenance. It does not store full window titles by default and does not collect keystrokes, clipboard contents, screenshots, webcam, microphone or document contents.

This framework-dependent build requires the .NET 10 desktop runtime.
